<?php $__env->startSection('title'); ?>
Add Offer
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contant'); ?>
<h3 class="text-dark">Add Offer</h3><hr>
    <form class="mt-5" action="<?php echo e(Route('offer.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6 col-12 form-group my-4">
                <label for="">Offer item</label>
                <select name="item_id" id="item_id" class="form-control">
                <option value="">-- Choose Item --</option>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['item_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 col-12 form-group my-4">
                <label for="">Offer percent</label>
                <input type="text" name="percent" id="percent" class="form-control">
                <?php $__errorArgs = ['percent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 col-12 form-group my-4">
                <label for="">Item price</label>
                <input type="text" name="price" id="price" class="form-control">
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 col-12 form-group my-4">
                <label for="">New price</label>
                <input type="text" name="new_price" id="new_price" class="form-control" readonly>
                <?php $__errorArgs = ['new_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 col-12 form-group my-4">
                <label for="">New price</label>
                <input type="date" name="date_expired" date-format="Y/m/d" id="date_expired" class="form-control">
                <?php $__errorArgs = ['date_expired'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="form-group mx-auto my-4">
                <input type="submit" value="Add" class="btn btn-info">
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
<script>
    $(document).ready(function() {
        $("#item_id").change(function(){
            var item_id = $("#item_id").val();
            var url = "<?php echo e(URL('admin/get_price')); ?>";
            dltUrl = url+"/"+item_id;
            $.ajax({
                    url: dltUrl,
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        $('#price').val(data);
                    },
                });
        });
        $('#percent').keyup(function(){
            var percent = $(this).val();
            var price =$('#price').val();
            var new_price = price - (price * (percent/100)) ;
            $('#new_price').val(new_price);
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project\resources\views/Admin/Offer/add.blade.php ENDPATH**/ ?>