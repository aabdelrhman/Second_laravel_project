<?php $__env->startSection('title'); ?>
Order
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contant'); ?>
<?php if(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php endif; ?>
    <h3 class="text-dark">Orders Items</h3><hr>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Item Name</th>
                <th scope="col">Category</th>
                <th scope="col">Short Description</th>
                <th scope="col">Amount</th>
                <th scope="col">price</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php
                            $category = App\Models\Item::with('category')->find($item->items->id);
                        ?>
                        <th scope="row"><?php echo e(++$index); ?></th>
                        <td><?php echo e($item->items->name); ?></td>
                        <td><?php echo e($category->category->name); ?></td>
                        <td><?php echo e($item->items->short_description); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <td><?php echo e($item->price); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table><hr>

        <h3 class="text-dark">Client Information</h3><hr>
        <form action="" method="get">
            <div class="row">
                <div class="form-group col-lg-6 col-12">
                    <label for="">First name</label>
                    <input type="text" name="" id="" value="<?php echo e($items[0]->order->fname); ?>" readonly class="form-control">
                </div>
                <div class="form-group col-lg-6 col-12">
                    <label for="">last name</label>
                    <input type="text" name="" id="" value="<?php echo e($items[0]->order->lname); ?>" readonly class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-lg-6 col-12">
                    <label for="">Email</label>
                    <input type="text" name="" id="" value="<?php echo e($items[0]->order->email); ?>" readonly class="form-control">
                </div>
                <div class="form-group col-lg-6 col-12">
                    <label for="">Phone</label>
                    <input type="text" name="" id="" value="<?php echo e($items[0]->order->phone); ?>" readonly class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-lg-6 col-12">
                    <label for="">Address</label>
                    <input type="text" name="" id="" value="<?php echo e($items[0]->order->addres); ?>" readonly class="form-control">
                </div>
                <div class="form-group col-lg-6 col-12">
                    <label for="">City</label>
                    <input type="text" name="" id="" value="<?php echo e($items[0]->order->city); ?>" readonly class="form-control">
                </div>
            </div>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project\resources\views/Admin/Order/show.blade.php ENDPATH**/ ?>