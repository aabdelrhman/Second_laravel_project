<?php $__env->startSection('title'); ?>
Order
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contant'); ?>
<?php if(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php endif; ?>
    <h3 class="text-dark">Orders</h3><hr>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Date order</th>
                <th scope="col">Opration</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(++$index); ?></th>
                        <td><?php echo e($order->fname); ?></td>
                        <td><?php echo e($order->lname); ?></td>
                        <td><?php echo e($order->email); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(Route('order_show' , $order->id)); ?>" class="btn btn-info">Show</a>
                            <?php if($order->accepted == 0): ?>
                                <a href="<?php echo e(Route('order_accepted' , $order->id)); ?>" class="btn btn-success">done</a>
                            <?php elseif($order->accepted == 1): ?>
                                <a href="<?php echo e(Route('order_refused' , $order->id)); ?>" class="btn btn-danger">Archif</a>
                            <?php elseif($order->accepted == 2): ?>
                                <a href="<?php echo e(Route('delete_order' , $order->id)); ?>" class="btn btn-danger">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project\resources\views/Admin/Order/index.blade.php ENDPATH**/ ?>