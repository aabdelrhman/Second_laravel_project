<?php $__env->startSection('title'); ?>
Items Offers
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contant'); ?>
<?php if(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php endif; ?>
    <h3 class="text-dark">Offers</h3><hr>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Item</th>
                <th scope="col">Offer percent</th>
                <th scope="col">New price</th>
                <th scope="col">Opration</th>
            </tr>
            </thead>
            <tbody>
                <?php if(isset($items)): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(++$index); ?></th>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->getoffer->offer_percent); ?>%</td>
                        <td><?php echo e($item->getoffer->new_price); ?>$</td>
                        <td>
                            
                            <a href="<?php echo e(Route('Delete_Offer',$item->id)); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>No offers</tr>
                <?php endif; ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project\resources\views/Admin/Offer/index.blade.php ENDPATH**/ ?>