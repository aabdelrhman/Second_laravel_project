<?php $__env->startSection('title'); ?>
Add Item Image
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contant'); ?>
<h3 class="text-dark">Add Item Image</h3><hr>
    <form class="mt-5" action="<?php echo e(Route('store_image' , $item_id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6 col-12 form-group my-4">
                <img src="<?php echo e(asset('images/images.png')); ?>" onclick="triggerclick()" class="" width="300px" id="prodis">
                <input type="file" name="item_photo" onchange="displayimage(this)" id="profileimage" style="display:none;">
            </div>
        </div>
        <div class="row">
            <div class="form-group mx-auto my-4">
                <input type="submit" value="Add" class="btn btn-info">
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project\resources\views/Admin/Item/add_image.blade.php ENDPATH**/ ?>