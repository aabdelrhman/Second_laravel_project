<?php $__env->startSection('title'); ?>
Add Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contant'); ?>
<h3 class="text-dark">Add Category</h3><hr>
    <form class="mt-5" action="<?php echo e(Route('category.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6 col-12 form-group my-4">
                <label for="">Category name</label>
                <input type="text" name="Category_name" id="" class="form-control" required>
                <?php $__errorArgs = ['Category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 col-12 form-group my-4">
                <label for="">Category photo</label>
                <input type="file" name="Category_photo" id="" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="form-group mx-auto my-4">
                <input type="submit" value="Add" class="btn btn-info">
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project\resources\views/Admin/Category/add_category.blade.php ENDPATH**/ ?>