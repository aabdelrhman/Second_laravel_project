@extends('layouts.admin.master')
@section('title')
Dashboard
@endsection
@section('contant')
    <h1>Hello World Dashboard </h1>
@endsection


